#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "iostream"
#include "logger.h"
#include <string>
#include <fstream>
#include "client.h"
#include "QJsonObject"
#include "QJsonDocument"
#include <stdio.h>
#include <unistd.h>
#include <vector>
using namespace std;

logger *l1 = new logger();
bool stop_stop = false; //Variable para detener la lectura de code_edit


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow){
    ui->setupUi(this);
    setWindowTitle("C! - IDE");
    ui->Application_Log->setDocumentTitle("Output");
    ui->Application_Log->setReadOnly(true);
    createClient();
}


MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_RunButton_clicked()
{
    string codigo = ui->CodeTextArea->toPlainText().toStdString() +'\n';

    convertidor->SplitString(codigo, '\n', linesCode);
    //cout << linesCode[0];

    addOutputArea();
    ui->RAM_view->insertRow(ui->RAM_view->rowCount());
    int fila = ui->RAM_view->rowCount() -1;

    addMemoryDirection(fila,cliente->jsonActual.value("Address").toString());
    addValor(fila,cliente->jsonActual.value("Value").toString());
    addEtiqueta(fila,cliente->jsonActual.value("Label").toString());
    addReferencia(fila);

    QString linea = QString("");
    addOutputArea();
}

//Envia al Stdout la informacion recibida
void MainWindow::addStdOutArea(QString linea){
    ui->Stdout->appendPlainText(linea);
}

//Log de ejecucion
void MainWindow::addOutputArea(){
    ui->Application_Log->appendPlainText(l1->logMessage(0,"Empezando ejecucion..."));
    ui->Application_Log->appendPlainText(l1->logMessage(0,"Enviando la informacion al servidor..."));
}

//Añade una direccion de memoria address al RAM Live View
void MainWindow::addMemoryDirection(int fila, QString address){
    ui->RAM_view->setItem(fila,Direccion,new QTableWidgetItem("address"));
}

// Añade un valor value al RAM Live View
void MainWindow::addValor(int fila,QString value){
    ui->RAM_view->setItem(fila,Valor,new QTableWidgetItem("value"));
}

//Añade una etiqueta label al RAM Live View
void MainWindow::addEtiqueta(int fila,QString label){
    ui->RAM_view->setItem(fila, Etiqueta,new QTableWidgetItem("label"));
}

//Añade una cantidad de referencias al RAM Live View
void MainWindow::addReferencia(int fila){
    ui->RAM_view->setItem(fila,Referencias,new QTableWidgetItem("1"));
}

//Instancia la clase Client
void MainWindow::createClient(){
    Client* client = new Client(0,"127.0.0.1",8888);
    cliente = client;
     ui->Application_Log->appendPlainText(l1->logMessage(0,"Estableciendo conexion con el servidor..."));
}

//Metodo para reiniciar la ejecucion
void MainWindow::on_pushButton_clicked()
{
    ui->Application_Log->appendPlainText(l1->logMessage(1,"Se reinicio el sistema..."));
}

//Metodo para detener la ejecucion
void MainWindow::on_stop_clicked()
{
    stop_stop = false;
    ui->Application_Log->appendPlainText(l1->logMessage(1,"Se detuvo la ejecucion"));
}

//Metodo para limpiar el app log
void MainWindow::on_clear_clicked()
{
    ui->Application_Log->clear();
}

void MainWindow::on_Next_clicked(){
    if (i < linesCode.size()){
        string instruccions = convertidor->EliminarEspacios( linesCode[i]);
        vector<string> line;

        convertidor->SplitString(instruccions, '#', line);

        string nombre;
        string valor;
        string tipo;

        if(line[0] == "int"){

            nombre = convertidor->getValor(line);
            valor = convertidor->getVariable(line);
            tipo = convertidor->getTipo(line);
            cout << tipo;
            cout << nombre;
            cout << valor;

        }else if (line[0] == "char"){

            nombre = convertidor->getValorChar(line);
            valor = convertidor->getVariable(line);
            tipo = convertidor->getTipo(line);
            cout << tipo;
            cout << nombre;
            cout << valor;

        }else if (line[0] == "long"){

            nombre = convertidor->getValor(line);
            valor = convertidor->getVariable(line);
            tipo = convertidor->getTipo(line);
            cout << tipo;
            cout << nombre;
            cout << valor;

        }else if (line[0] == "double"){

            nombre = convertidor->getValor(line);
            valor = convertidor->getVariable(line);
            tipo = convertidor->getTipo(line);
            cout << tipo;
            cout << nombre;
            cout << valor;

        }else if (line[0] == "float"){

            nombre = convertidor->getValor(line);
            valor = convertidor->getVariable(line);
            tipo = convertidor->getTipo(line);
            cout << tipo;
            cout << nombre;
            cout << valor;

        }else if (line[0] == "{"){

            valor= "Generate";

        }else if(line[0] == "}"){

            valor = "Eliminar";

        }else if (line[0] == "reference"){

            valor = convertidor->GenerarReference(line);
            cout << valor;

        }else if(line[0] == "cout"){

            valor = convertidor->GenerarCout(line);

        }

        if(valor == "error"){
            //EJECUTAR ERROR
        }

        line.clear();
        i++;


    }
}

